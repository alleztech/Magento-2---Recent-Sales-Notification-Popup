var config = {
      map: {
          '*': {
              alleztechsalesnotification: 'AllezTech_SalesNotification/js/salesnotification',
            
        shim: {
            'alleztechsalesnotification': {
                'deps': ['jquery']
            }
        }
          }
      }
  }; 

